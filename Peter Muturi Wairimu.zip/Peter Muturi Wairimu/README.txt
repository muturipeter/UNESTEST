My name is Peter Muturi Wairimu. README file for the coding task assigned.
Github Profile:/muturipeter
Linked Profile:/muturipeter

Scoring criteria covered:
1. Software Design and Development
2. UI and Navigation
3. Database design and development.

IDE's used;
*Pycharm for python source code
 
TOOLS:
*Xammp for local database environment.
 



Language=Python "comment"

Question:2
iF ELSE,
wait
dictionary
delay
queing 

Methodology:Agile _Test based development and design

*Database Design*
MYSQL*
Database Name:Peter_Muturi_wairimu
Database model:relational (for the 8 elevators)
Tables:
Elevators


Language=Python

Question:4
iF ELSE,
wait
import timestamp
import time
array
delay
queing 

Methodology:Agile _Test based development and design

*Database Design*
Database model:relational (for the 8 elevators)
Tables:
Elevators










