import main


class MyTestCase(main.TestCase):
    def test_regex(self):
        self.assertEqual(True, False)  #


if __name__ == '__main__':
    unittest.main()
#Din't get a chance to conduct a Unit test for my program since python interpreter was missing.
