# This is a sample Python code snipet to store and match the custom 'regex' strings
#Developer: Peter Muturi Wairimu
#NB:No interpreter was found on the pre-installed IDE
#Date last git commit:11/10/2022
#Github:https://github.com/muturipeter
#Start be importing libraries in use
import re
dict= {}
dict[re.compile('actionname (\d+) (\d+)')] = method
dict[re.compile('differentaction (\w+) (\w+)')] = appropriate_method
 def alphabet (str) args[x]:

#Create Variable X and assign it a value 'a'
x='a'

def execute_method_for(str):
    #Match each regex on the string
    if
    matches = (
        (regex.match(str), f) for regex, f in dict.iteritems() #items stored as dictionarries on the project Data structure
    )
    else

    #Filter out empty matches,
    matches = (
        (match.groups(), f) for match, f in matches if match is not None
    )
    #Get to apply the functions above
    for args, f in matches:
        f(*args)

